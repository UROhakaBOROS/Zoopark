﻿using AnimalMiroservice.Dtos;

namespace AnimalMiroservice.AsyncDataServices
{
    public interface IMessageBusClient
    {
        void PublishNewAnimal(AnimalPublishedDTO AnimalPublishedDTO);
    }
}
