﻿using AutoMapper;
using AnimalMiroservice.AsyncDataServices;
using AnimalMiroservice.Data;
using AnimalMiroservice.Dtos;
using AnimalMiroservice.Models;
using AnimalMiroservice.SyncDataServices.Http;
using Microsoft.AspNetCore.Mvc;

namespace AnimalMiroservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalController : ControllerBase
    {
        private readonly IAnimalRepository _repository;
        private readonly IMapper _mapper;
        private readonly ICommandDataClient _commandDataClient;
        private readonly ILogger<AnimalController> _logger;
        private readonly IMessageBusClient _messageBusClient;

        public AnimalController(IAnimalRepository repository, IMapper mapper, ICommandDataClient commandDataClient, 
            IMessageBusClient messageBusClient, ILogger<AnimalController> logger)
        {
            _repository = repository;
            _mapper = mapper;
            _commandDataClient = commandDataClient;
            _messageBusClient = messageBusClient;
            _logger = logger;
        }

        #region API
        [HttpGet("all")]
        public ActionResult<IEnumerable<AnimalReadDTO>> GetAllAnimals()
        {
            _logger.LogInformation("--> Getting Animals....");

            return Ok(_mapper.Map<IEnumerable<AnimalReadDTO>>(_repository.GetAllAnimals()));
        }

        [HttpGet("get/{id}", Name = "GetAnimalById")]
        public ActionResult<AnimalReadDTO> GetAnimalById(int id) 
        {
            var Animal = _repository.GetAnimalById(id);

            if (Animal != null)
            {
                return Ok(_mapper.Map<AnimalReadDTO>(Animal));
            }

            return NotFound();
        }

        [HttpPost("create")]
        public async Task<ActionResult<AnimalReadDTO>> CreateAnimal(AnimalCreateDTO AnimalCreateDTO)
        {
            var AnimalToCreate = _mapper.Map<Animal>(AnimalCreateDTO);

            _repository.CreateAnimal(AnimalToCreate);
            _repository.SaveChanges();

            var AnimalReadDTO = _mapper.Map<AnimalReadDTO>(AnimalToCreate);

            try
            {
                await _commandDataClient.SendAnimalToCommand(AnimalReadDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"--> Could not send synchronously: {ex.Message}");
            }

            try
            {
                var AnimalPublishedDTO = _mapper.Map<AnimalPublishedDTO>(AnimalReadDTO);
                AnimalPublishedDTO.Event = "Animal_Published";
                _messageBusClient.PublishNewAnimal(AnimalPublishedDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"--> Could not send asynchronously: {ex.Message}");
            }

            return CreatedAtRoute(nameof(GetAnimalById), new { Id = AnimalReadDTO.Id }, AnimalReadDTO);
        }
        #endregion
    }
}
