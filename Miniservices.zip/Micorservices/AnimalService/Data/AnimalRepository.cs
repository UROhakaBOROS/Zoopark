﻿using AnimalMiroservice.Models;

namespace AnimalMiroservice.Data
{
    public class AnimalRepository : IAnimalRepository
    {
        private readonly AppDdContext _context;
        
        public AnimalRepository(AppDdContext context)
        {
            _context = context;
        }

        public void CreateAnimal(Animal Animal)
        {
            if (Animal == null)
            {
                throw new ArgumentNullException(nameof(Animal));
            }

            _context.Animals.Add(Animal);
        }

        public IEnumerable<Animal> GetAllAnimals()
        {
            return _context.Animals.ToList();
        }

        public Animal? GetAnimalById(int id)
        {
            return _context.Animals.FirstOrDefault(Animal => Animal.Id == id);
        }

        public bool SaveChanges()
        {
            return (_context.SaveChanges() >= 0);
        }
    }
}
