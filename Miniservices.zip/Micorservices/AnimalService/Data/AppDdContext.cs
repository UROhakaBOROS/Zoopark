﻿using AnimalMiroservice.Models;
using Microsoft.EntityFrameworkCore;

namespace AnimalMiroservice.Data
{
    public class AppDdContext : DbContext
    {
        public DbSet<Animal> Animals { get; set; }

        public AppDdContext(DbContextOptions<AppDdContext> options) : base(options) 
        {
            
        }
    }
}
