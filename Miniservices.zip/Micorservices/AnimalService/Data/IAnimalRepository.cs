﻿using AnimalMiroservice.Models;

namespace AnimalMiroservice.Data
{
    public interface IAnimalRepository
    {
        bool SaveChanges();

        IEnumerable<Animal> GetAllAnimals();
        Animal? GetAnimalById(int id);
        void CreateAnimal(Animal Animal);
    }
}
