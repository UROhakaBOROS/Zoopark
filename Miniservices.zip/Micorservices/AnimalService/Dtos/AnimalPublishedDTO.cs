﻿namespace AnimalMiroservice.Dtos
{
    public class AnimalPublishedDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Event { get; set; }
    }
}
