﻿namespace AnimalMiroservice.Dtos
{
    public class AnimalReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Breed { get; set; }
        public float Veight { get; set; }
        public float Lenght { get; set; }
    }
}
