﻿using System.ComponentModel.DataAnnotations;

namespace AnimalMiroservice.Models
{
    public class Animal
    {
        [Key]
        [Required] public int Id { get; set; }
        [Required] public string Name { get; set; }
        [Required] public string Breed { get; set; }
        [Required] public float Veight { get; set; }
        [Required] public float Lenght { get; set; }
    }
}
