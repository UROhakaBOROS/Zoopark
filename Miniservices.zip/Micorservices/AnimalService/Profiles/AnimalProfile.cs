﻿using AutoMapper;
using AnimalMiroservice.Dtos;
using AnimalMiroservice.Models;
using AnimalMiroservice.Protos;

namespace AnimalMiroservice.Profiles
{
    public class AnimalProfile : Profile
    {
        public AnimalProfile() 
        {
            CreateMap<Animal, AnimalReadDTO>();
            CreateMap<AnimalCreateDTO, Animal>();
            CreateMap<AnimalReadDTO, AnimalPublishedDTO>();
            CreateMap<Animal, GrpcAnimalModel>()
                .ForMember(dest => dest.AnimalId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Breed, opt => opt.MapFrom(src => src.Breed))
                .ForMember(dest => dest.Veight, opt => opt.MapFrom(src => src.Veight))
                .ForMember(dest => dest.Lenght, opt => opt.MapFrom(src => src.Lenght));
        }
    }
}
