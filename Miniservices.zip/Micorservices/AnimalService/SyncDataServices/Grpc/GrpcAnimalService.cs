﻿using AutoMapper;
using AnimalMiroservice.Data;
using AnimalMiroservice.Protos;
using Grpc.Core;

namespace AnimalMiroservice.SyncDataServices.Grpc
{
    public class GrpcAnimalService : GrpcAnimal.GrpcAnimalBase
    {
        private readonly IAnimalRepository _repository;
        private readonly ILogger<GrpcAnimalService> _logger;
        private readonly IMapper _mapper;

        public GrpcAnimalService(IAnimalRepository repository, ILogger<GrpcAnimalService> logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public override Task<AnimalResponse> GetAllAnimals(GetAllRequest request, ServerCallContext context)
        {
            var response = new AnimalResponse();
            var Animals = _repository.GetAllAnimals();

            foreach (var Animal in Animals)
            {
                response.Animal.Add(_mapper.Map<GrpcAnimalModel>(Animal));
            }

            return Task.FromResult(response);
        }
    }
}
