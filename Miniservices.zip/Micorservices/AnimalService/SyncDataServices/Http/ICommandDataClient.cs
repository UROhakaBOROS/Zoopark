﻿using AnimalMiroservice.Dtos;

namespace AnimalMiroservice.SyncDataServices.Http
{
    public interface ICommandDataClient
    {
        Task SendAnimalToCommand(AnimalReadDTO Animal);
    }
}
