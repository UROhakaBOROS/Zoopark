﻿using AutoMapper;
using CommandsService.Data;
using CommandsService.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CommandsService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalController : ControllerBase
    {
        private readonly ICommandRepository _repository;
        private readonly IMapper _mapper;
        private readonly ILogger<AnimalController> _logger;

        public AnimalController(ICommandRepository repository, IMapper mapper, ILogger<AnimalController> logger)
        {
            _repository = repository;
            _mapper = mapper;
            _logger = logger;
        }

        #region API
        [HttpGet("all")]
        public ActionResult<IEnumerable<AnimalReadDTO>> GetAnimals()
        {
            _logger.LogInformation("--> Getting Animals from CommandsService");

            return Ok(_mapper.Map<IEnumerable<AnimalReadDTO>>(_repository.GetAllAnimals()));
        }

        [HttpPost]
        public ActionResult TestInboundConnection()
        {
            _logger.LogInformation("--> Inbound POST # Command Service");

            return Ok("Inbound test of from Animals Controler");
        }
        #endregion
    }
}
