﻿using AutoMapper;
using CommandsService.Data;
using CommandsService.Dtos;
using CommandsService.Models;
using Microsoft.AspNetCore.Mvc;

namespace CommandsService.Controllers
{
    [Route("api/c/animals/{animalId}/[controller]")]
    [ApiController]
    public class CommandsController : ControllerBase
    {
        private readonly ICommandRepository _repository;
        private readonly IMapper _mapper;
        private readonly ILogger<CommandRepository> _logger;

        public CommandsController(ICommandRepository repository, IMapper mapper, ILogger<CommandRepository> logger)
        {
            _repository = repository;
            _mapper = mapper;
            _logger = logger;
        }

        #region API
        [HttpGet("all")]
        public ActionResult<IEnumerable<CommandReadDTO>> GetCommandsForAnimal(int fabricId)
        {
            _logger.LogInformation($"--> Hit GetCommandsForAnimal: {fabricId}");

            if (!_repository.AnimalExits(fabricId))
            {
                return NotFound();
            }

            return Ok(_mapper.Map<CommandReadDTO>(_repository.GetCommandsForAnimal(fabricId)));
        }

        [HttpGet("by-command-id/{commandId}", Name = "GetCommandForAnimal")]
        public ActionResult<CommandReadDTO> GetCommandForAnimal(int fabricId, int commandId)
        {
            _logger.LogInformation($"--> Hit GetCommandForAnimal: {fabricId} / {commandId}");

            if (!_repository.AnimalExits(fabricId))
            {
                return NotFound();
            }

            var command = _repository.GetCommand(fabricId, commandId);

            if (command == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<CommandReadDTO>(command));
        }

        [HttpPost]
        public ActionResult<CommandReadDTO> CreateCommandForAnimal(int fabricId, CommandCreateDTO commandCreateDTO)
        {
            _logger.LogInformation($"--> Hit CreateCommandForAnimal: {fabricId}");

            if (!_repository.AnimalExits(fabricId))
            {
                return NotFound();
            }

            var command = _mapper.Map<Command>(commandCreateDTO);

            _repository.CreateCommand(fabricId, command);
            _repository.SaveChanges();

            var commandReadDTO = _mapper.Map<CommandReadDTO>(command);

            return CreatedAtRoute(nameof(GetCommandForAnimal),
                new { fabricId = fabricId, commandId = commandReadDTO.Id }, commandReadDTO);
        }
        #endregion
    }
}
