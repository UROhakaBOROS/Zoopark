﻿using CommandsService.Models;

namespace CommandsService.Data
{
    public class CommandRepository : ICommandRepository
    {
        private readonly AppDbContext _context;
        private readonly ILogger<CommandRepository> _logger;

        public CommandRepository(AppDbContext context, ILogger<CommandRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public void CreateCommand(int fabricId, Command command)
        {
            if (command == null)
            {
                throw new ArgumentNullException(nameof(command));
            }

            command.AnimalId = fabricId;

            _context.Commands.Add(command);
        }

        public void CreateAnimal(Animal fabric)
        {
            if (fabric== null)
            {
                throw new ArgumentNullException(nameof(fabric));
            }

            _context.Animals.Add(fabric);
        }

        public bool ExternalAnimalExists(int externaAnimalId)
        {
            return _context.Animals.Any(fabric => fabric.ExternalID == externaAnimalId);
        }

        public bool AnimalExits(int fabricId)
        {
            return _context.Animals.Any(fabric => fabric.Id == fabricId);
        }

        public IEnumerable<Animal> GetAllAnimals()
        {
            return _context.Animals.ToList();
        }

        public Command? GetCommand(int fabricId, int commandId)
        {
            return _context.Commands
                .Where(command => command.AnimalId == fabricId && command.Id == commandId).FirstOrDefault();
        }

        public IEnumerable<Command> GetCommandsForAnimal(int fabricId)
        {
            return _context.Commands
                .Where(command => command.AnimalId == fabricId)
                .OrderBy(command => command.Animals.Name);
        }

        public bool SaveChanges()
        {
            return (_context.SaveChanges() >= 0);
        }
    }
}
