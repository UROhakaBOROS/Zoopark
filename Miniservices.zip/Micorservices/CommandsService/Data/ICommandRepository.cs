﻿using CommandsService.Models;

namespace CommandsService.Data
{
    public interface ICommandRepository
    {
        bool SaveChanges();

        // Animals
        IEnumerable<Animal> GetAllAnimals();
        void CreateAnimal(Animal fabric);
        bool AnimalExits(int fabricId);
        bool ExternalAnimalExists(int externaAnimalId);

        // Commands
        IEnumerable<Command> GetCommandsForAnimal(int fabricId);
        Command? GetCommand(int fabricId, int commandId);
        void CreateCommand(int fabricId, Command command);
    }
}
