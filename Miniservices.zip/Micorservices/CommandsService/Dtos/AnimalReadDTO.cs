﻿namespace CommandsService.Dtos
{
    public class AnimalReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
