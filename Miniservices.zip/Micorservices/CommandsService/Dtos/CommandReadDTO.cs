﻿namespace CommandsService.Dtos
{
    public class CommandReadDTO
    {
        public int Id { get; set; }
        public string HowTo { get; set; }
        public string Action { get; set; }
        public int AnimalId { get; set; }
    }
}
