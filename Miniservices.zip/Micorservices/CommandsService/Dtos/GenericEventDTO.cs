﻿namespace CommandsService.Dtos
{
    public class GenericEventDTO
    {
        public string Event { get; set; }
    }
}
