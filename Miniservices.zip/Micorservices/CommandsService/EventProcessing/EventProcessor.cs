﻿using AutoMapper;
using CommandsService.Data;
using CommandsService.Dtos;
using CommandsService.Models;
using System.Text.Json;

namespace CommandsService.EventProcessing
{
    public class EventProcessor : IEventProcessor
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IMapper _mapper;
        private readonly ILogger<EventProcessor> _logger;

        public EventProcessor (IServiceScopeFactory scopeFactory, IMapper mapper, ILogger<EventProcessor> logger)
        {
            _scopeFactory = scopeFactory;
            _mapper = mapper;
            _logger = logger;
        }

        public void ProcessEvent(string message)
        {
            var eventType = DetermineEvent(message);

            switch (eventType)
            {
                case EventType.AnimalPublished:
                    {
                        AddAnimal(message);
                    }
                    break;
                default:
                    break;
            }
        }

        private EventType DetermineEvent(string notifcationMessage)
        {
            _logger.LogInformation("--> Determining Event");

            var eventType = JsonSerializer.Deserialize<GenericEventDTO>(notifcationMessage);

            switch (eventType.Event)
            {
                case "Animal_Published":
                    {
                        _logger.LogInformation("--> Animal Published Event Detected");

                        return EventType.AnimalPublished;
                    }
                default:
                    {
                        _logger.LogInformation("--> Could not determine the event type");

                        return EventType.Undetermined;
                    }
            }
        }

        private void AddAnimal(string fabriAnimalblishedMessage)
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var repository = scope.ServiceProvider.GetRequiredService<ICommandRepository>();

                var fabriAnimalblishedDto = JsonSerializer.Deserialize<AnimalPublishedDTO>(fabriAnimalblishedMessage);

                try
                {
                    var plat = _mapper.Map<Animal>(fabriAnimalblishedDto);
                    if (!repository.ExternalAnimalExists(plat.ExternalID))
                    {
                        repository.CreateAnimal(plat);
                        repository.SaveChanges();

                        _logger.LogInformation("--> Animal added!");
                    }
                    else
                    {
                        _logger.LogWarning("--> Animal already exisits...");
                    }

                }
                catch (Exception ex)
                {
                    _logger.LogError($"--> Could not add Animal to DB {ex.Message}");
                }
            }
        }
    }

    enum EventType
    {
        AnimalPublished,
        Undetermined
    }
}
