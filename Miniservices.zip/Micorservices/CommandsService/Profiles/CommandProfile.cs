﻿using AutoMapper;
using CommandsService.Dtos;
using CommandsService.Models;
using CommandsService.Protos;

namespace CommandsService.Profiles
{
    public class CommandProfile : Profile
    {
        public CommandProfile() 
        {
            CreateMap<Animal, AnimalReadDTO>();
            CreateMap<CommandCreateDTO, Command>();
            CreateMap<Command, CommandReadDTO>();
            CreateMap<AnimalPublishedDTO, Animal>()
                .ForMember(dest => dest.ExternalID, opt => opt.MapFrom(src => src.Id));
            CreateMap <GrpcAnimalModel, Animal> ()
                .ForMember(dest => dest.ExternalID, opt => opt.MapFrom(src => src.AnimalId))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name))
                .ForMember(dest => dest.Commands, opt => opt.Ignore());
        }
    }
}
