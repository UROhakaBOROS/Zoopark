﻿using AutoMapper;
using CommandsService.Models;
using CommandsService.Protos;
using Grpc.Net.Client;

namespace CommandsService.SyncDataServices.Grpc
{
    public class AnimalDataClient : IAnimalDataClient
    {
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly ILogger<AnimalDataClient> _logger;

        public AnimalDataClient(IConfiguration configuration, IMapper mapper, ILogger<AnimalDataClient> logger)
        {
            _configuration = configuration;
            _mapper = mapper;
            _logger = logger;
        }

        public IEnumerable<Animal>? ReturnAllAnimals()
        {
            _logger.LogInformation($"--> Calling GRPC Service {_configuration["GrpcAnimal"]}");

            var channel = GrpcChannel.ForAddress(_configuration["GrpcAnimal"]);
            var client = new GrpcAnimal.GrpcAnimalClient(channel);
            var request = new GetAllRequest();

            try
            {
                var reply = client.GetAllAnimals(request);
                return _mapper.Map<IEnumerable<Animal>>(reply.Animal);
            }
            catch (Exception ex)
            {
                _logger.LogError($"--> Couldnot call GRPC Server {ex.Message}");
                return null;
            }
        }
    }
}
